import math
import logging
import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm
import copy, wandb
from methods.base import BaseLearner
from utils.data_manager import setup_seed, partition_data, DatasetSplit, average_weights
from utils.inc_net import IncrementalNet
from torch import nn
import torch.optim as optim
from copy import deepcopy
import convs
from convs.generator import CIFAR_GEN

class Teacher(nn.Module):
    def __init__(self, solver, generator, gen_opt, img_shape, iters, class_idx, deep_inv_params, train, args):
        super().__init__()
        self.solver = solver
        self.generator = generator
        self.gen_opt = gen_opt
        self.solver.eval()
        self.generator.eval()
        self.img_shape = img_shape
        self.iters = iters
        self.bn_loss = 1
        self.noise = 1
        self.ie_loss = 1
        self.act_loss = 0
        self.w_ie = 1
        self.w_act = 0.1
        self.di_lr = deep_inv_params[0]
        self.r_feature_weight = deep_inv_params[1]
        self.di_var_scale = deep_inv_params[2]
        self.content_temp = deep_inv_params[3]
        self.content_weight = deep_inv_params[4]
        self.class_idx = list(class_idx)
        self.num_k = len(self.class_idx)
        self.first_time = train
        self.criterion = nn.CrossEntropyLoss()
        self.mse_loss = nn.MSELoss(reduction="none").to('cuda')
        self.smoothing = Gaussiansmoothing(3, 5, 1)
        if self.bn_loss:
            loss_r_feature_layers = []
            for module in self.solver.modules():
                if isinstance(module, nn.BatchNorm2d) or isinstance(module, nn.BatchNorm1d) or isinstance(module, nn.GroupNorm):
                    loss_r_feature_layers.append(DeepInversionFeatureHook(module, 0, self.r_feature_weight))
            self.loss_r_feature_layers = loss_r_feature_layers

    def sample(self, size, return_scores=False):
        self.solver.eval()
        self.generator.train()
        if self.first_time:
            self.first_time = False
            self.get_images(bs=size, epochs=self.iters, idx=-1)
        self.generator.eval()
        with torch.no_grad():
            x_i = self.generator.sample(size, 'cuda')
        with torch.no_grad():
            outputs = self.solver(x_i)
            y_hat = outputs['logits']
        y_hat = y_hat[:, self.class_idx]
        _, y = torch.max(y_hat, dim=1)
        return (x_i, y, y_hat) if return_scores else (x_i, y)

    def generate_scores(self, x, allowed_predictions=None, return_label=False):
        self.solver.eval()
        with torch.no_grad():
            outputs = self.solver(x)
            y_hat = outputs['logits']
        if allowed_predictions is not None:
            y_hat = y_hat[:, allowed_predictions]
        _, y = torch.max(y_hat, dim=1)
        return (y, y_hat) if return_label else y_hat

    def generate_scores_pen(self, x):
        self.solver.eval()
        with torch.no_grad():
            # 使用convnet来提取特征而不是使用不存在的feature_extractor
            outputs = self.solver(x)
            y_hat = outputs['features']  # 使用features而不是直接调用feature_extractor
        return y_hat

    def get_images(self, bs=256, epochs=1000, idx=-1):
        torch.cuda.empty_cache()
        self.generator.train()
        self.generator.to('cuda')
        for epoch in tqdm(range(epochs)):
            inputs = self.generator.sample(bs, 'cuda')
            self.gen_opt.zero_grad()
            self.solver.zero_grad()
            bn_loss = 0
            # content
            if self.act_loss:
                features_t = self.solver.feature(inputs)
                outputs = self.solver.fc(features_t)['logits']
                outputs = outputs[:, :self.num_k]
                loss = self.criterion(outputs / self.content_temp, torch.argmax(outputs, dim=1)) * self.content_weight
                loss += - features_t[-1].abs().mean() * self.w_act
            else:
                outputs = self.solver(inputs)['logits']
                outputs = outputs[:, :self.num_k]
                ce_loss = self.criterion(outputs / self.content_temp, torch.argmax(outputs, dim=1)) * self.content_weight
                loss = ce_loss

            if self.ie_loss:
                softmax_o_T = F.softmax(outputs, dim=1).mean(dim=0)
                ie_loss = (1.0 + (softmax_o_T * torch.log(softmax_o_T) / math.log(self.num_k)).sum()) * self.w_ie
                loss += ie_loss
            # R_feature loss
            if self.bn_loss:
                for mod in self.loss_r_feature_layers:
                    loss_distr = mod.r_feature * self.r_feature_weight / len(self.loss_r_feature_layers)
                    bn_loss = bn_loss + loss_distr
                loss += bn_loss

            # image prior
            if self.noise:
                inputs_smooth = self.smoothing(F.pad(inputs, (2, 2, 2, 2), mode='reflect'))
                loss_var = self.mse_loss(inputs, inputs_smooth).mean()
                noise_loss = self.di_var_scale * loss_var
                loss += noise_loss
            loss.backward()
            self.gen_opt.step()
        torch.cuda.empty_cache()
        self.generator.eval()


class DeepInversionFeatureHook():
    def __init__(self, module, gram_matrix_weight, layer_weight):
        self.hook = module.register_forward_hook(self.hook_fn)
        self.target = None
        self.gram_matrix_weight = gram_matrix_weight
        self.layer_weight = layer_weight

    def hook_fn(self, module, input, output):
        nch = input[0].shape[1]
        mean = input[0].mean([0, 2, 3])
        var = input[0].permute(1, 0, 2, 3).contiguous().view([nch, -1]).var(1, unbiased=False) + 1e-8
        x = module.running_var.data.type(var.type())
        y = module.running_mean.data.type(var.type())
        m1 = torch.log(var**(0.5) / (x + 1e-8)**(0.5)).mean()
        r_feature = m1 - 0.5 * (1.0 - (x + 1e-8 + (y - mean)**2) / var).mean()
        self.r_feature = r_feature

    def close(self):
        self.hook.remove()


class Gaussiansmoothing(nn.Module):
    def __init__(self, channels, kernel_size, sigma, dim=2):
        super(Gaussiansmoothing, self).__init__()
        kernel_size = [kernel_size] * dim
        sigma = [sigma] * dim
        kernel = 1
        meshgrids = torch.meshgrid([torch.arange(size, dtype=torch.float32) for size in kernel_size])
        for size, std, mgrid in zip(kernel_size, sigma, meshgrids):
            mean = (size - 1) / 2
            kernel *= 1 / (std * math.sqrt(2 * math.pi)) * torch.exp(-((mgrid - mean) / (2 * std)) ** 2)

        kernel = kernel / torch.sum(kernel)
        kernel = kernel.view(1, 1, *kernel.size())
        kernel = kernel.repeat(channels, *[1] * (kernel.dim() - 1)).to('cuda')
        self.register_buffer('weight', kernel)
        self.groups = channels
        if dim == 1:
            self.conv = F.conv1d
        elif dim == 2:
            self.conv = F.conv2d
        elif dim == 3:
            self.conv = F.conv3d
        else:
            raise RuntimeError('Only 1, 2 and 3 dimensions are supported. Received {}.'.format(dim))

    def forward(self, input):
        return self.conv(input, weight=self.weight, groups=self.groups)


class MFCL(BaseLearner):
    def __init__(self, args):
        super(MFCL, self).__init__(args)
        self.kd_criterion = nn.MSELoss(reduction="none")
        self.last_valid_dim = 0
        self.valid_dim = 0
        self.mu = 1e-1
        self.generator = CIFAR_GEN(zdim=1000, convdim=64)
        self.teacher = None
        self.ft_weight = 1
        self.syn_size = 128
        self._network = IncrementalNet(args, False)
        self.exp_name = args["exp_name"]
        self.criterion_fn = F.cross_entropy

    def after_task(self):
        self._old_network = self._network.copy().freeze()
        self._known_classes = self._total_classes
        self.teacher = self.train_gen(deepcopy(self._network), self._known_classes, self.generator, self.args)
        self.last_valid_dim = self._total_classes
        self.valid_dim = self.last_valid_dim + 10
        self.save_checkpoint(self.exp_name)


    def incremental_train(self, data_manager):
        self._cur_task += 1
        self._total_classes = self._known_classes + data_manager.get_task_size(
            self._cur_task
        )
        self.task_size = self._total_classes - self._known_classes
        self._network.update_fc(self._total_classes)
        logging.info(
            "Learning on {}-{}".format(self._known_classes, self._total_classes)
        )

        train_dataset = data_manager.get_dataset(
            np.arange(self._known_classes, self._total_classes),
            source="train",
            mode="train",
        )
        test_dset = data_manager.get_dataset(
            np.arange(0, self._total_classes), source="test", mode="test"
        )

        self.test_loader = DataLoader(
            test_dset, batch_size=256, shuffle=False, num_workers=4
        )
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self._network.to(device)
        setup_seed(self.seed)
        self._fl_train(train_dataset, self.test_loader, data_manager)

    def _local_update(self, model, train_data_loader):
        model.train()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9, weight_decay=5e-4)
        for iter in range(5):
            for batch_idx, (_, images, labels) in enumerate(train_data_loader):
                device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)
                logits = outputs["logits"]
                loss = F.cross_entropy(logits, labels)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
        return model.state_dict()

    def _local_finetune(self, model, teacher, generator, train_data_loader):
        model.train()
        self.dw_k = torch.ones((self.valid_dim + 1), dtype=torch.float32)
        previous_teacher, previous_linear = deepcopy(teacher[0]), deepcopy(teacher[1])
        opt = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9, weight_decay=5e-4)
        for iter in range(5):
            for batch_idx, (_, x, y) in enumerate(train_data_loader):
                x, y = x.to('cuda'), y.to('cuda')
                idx1 = torch.where(y >= self.last_valid_dim)[0]
                x_replay, y_replay, y_replay_hat = self.sample(previous_teacher, self.syn_size)
                y_hat = previous_teacher.generate_scores(x, allowed_predictions=np.arange(self.last_valid_dim))
                _, y_hat_com = combine_data(((x, y_hat), (x_replay, y_replay_hat)))
                x_com, y_com = combine_data(((x, y), (x_replay, y_replay)))
                logits_pen = model(x_com)["features"]
                logits = model(x_com)["logits"]
                mappings = torch.ones(self.valid_dim, dtype=torch.float32, device='cuda') 
                dw_cls = mappings[y_com.long()]
                loss_class = self.criterion(logits[idx1, self.last_valid_dim:self.valid_dim], (y_com[idx1] - self.last_valid_dim), dw_cls[idx1])
                with torch.no_grad():
                    feat_class = model(x_com)["features"].detach()
                fc_out = model.fc(feat_class)
                if isinstance(fc_out, dict):
                    fc_logits = fc_out['logits']
                else:
                    fc_logits = fc_out
                loss_class += self.criterion(fc_logits, y_com, dw_cls) * self.ft_weight
                loss_kd = self.kd(x_com, previous_linear, logits_pen, previous_teacher)
                total_loss = loss_class + loss_kd
                opt.zero_grad()
                total_loss.backward()
                opt.step()
        return model.state_dict()

    def _fl_train(self, train_dataset, test_loader, data_manager):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self._network.to(device)
        user_groups = partition_data(train_dataset.labels, self.args["seed"], beta=self.args["beta"], n_parties=self.args["num_users"])
        prog_bar = tqdm(range(self.args["com_round"]))
        for _, com in enumerate(prog_bar):
            local_weights = []
            m = max(int(self.args["frac"] * self.args["num_users"]), 1)
            idxs_users = np.random.choice(range(self.args["num_users"]), m, replace=False)
            for idx in idxs_users:
                local_train_loader = DataLoader(DatasetSplit(train_dataset, user_groups[idx]),
                                                batch_size=self.args["local_bs"], shuffle=True, num_workers=4)
                if self._cur_task == 0:
                    w = self._local_update(copy.deepcopy(self._network), local_train_loader)
                else:
                    w = self._local_finetune(copy.deepcopy(self._network),self.teacher, self.generator, local_train_loader)
                local_weights.append(copy.deepcopy(w))
            # update global weights
            global_weights = average_weights(local_weights)
            self._network.load_state_dict(global_weights)
            if com % 1 == 0:
                # pdb.set_trace()
                test_acc = self._compute_accuracy(self._network, test_loader)
                info = ("Task {}, Epoch {}/{} =>  Test_accy {:.2f}".format(
                    self._cur_task, com + 1, self.args["com_round"], test_acc, ))
                prog_bar.set_description(info)
                if self.wandb == 1:
                    wandb.log({'Task_{}, accuracy'.format(self._cur_task): test_acc})


    def kd(self, x_com, previous_linear, logits_pen, previous_teacher):
        kd_index = np.arange(x_com.size(0))
        dw_KD = self.dw_k[-1 * torch.ones(len(kd_index),).long()].to('cuda')
         # 处理当前logits
        outputs_KD = previous_linear(logits_pen[kd_index])
        if isinstance(outputs_KD, dict):
            logits_KD = outputs_KD['logits']
        else:
            logits_KD = outputs_KD
        logits_KD = logits_KD[:, :self.last_valid_dim]
        
        # 处理past logits
        outputs_KD_past = previous_linear(previous_teacher.generate_scores_pen(x_com[kd_index]))
        if isinstance(outputs_KD_past, dict):
            logits_KD_past = outputs_KD_past['logits']
        else:
            logits_KD_past = outputs_KD_past
        logits_KD_past = logits_KD_past[:, :self.last_valid_dim]
        loss_kd = self.mu * (self.kd_criterion(logits_KD, logits_KD_past).sum(dim=1) * dw_KD).mean() / (logits_KD.size(1))
        return loss_kd

    def sample(self, teacher, dim, return_scores=True):
        return teacher.sample(dim, return_scores=return_scores)

    def criterion(self, logits, targets, data_weights):
        return (self.criterion_fn(logits, targets) * data_weights).mean()
    
    def train_gen(self, model, valid_out_dim, generator, args):
        dataset_size = (-1, 3, 32, 32)
        model.to('cuda')
        generator_optimizer = torch.optim.Adam(params=generator.parameters(), lr=0.001)
        teacher = Teacher(solver=model, generator=generator, gen_opt=generator_optimizer,
                        img_shape=dataset_size, iters=100, deep_inv_params=[1e-3, 5e1, 1e-3, 1e3, 1],
                        class_idx=np.arange(valid_out_dim), train=True, args=args)
        teacher.sample(128, return_scores=False)
        return teacher, deepcopy(model.fc)


def combine_data(data):
    x, y = [], []
    for i in range(len(data)):
        x.append(data[i][0])
        y.append(data[i][1])
    x, y = torch.cat(x), torch.cat(y)
    return x, y